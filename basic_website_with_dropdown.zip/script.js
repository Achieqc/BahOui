// script.js
function changeColor() {
    document.body.style.backgroundColor = "lightblue";
}
